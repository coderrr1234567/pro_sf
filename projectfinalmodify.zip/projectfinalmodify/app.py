from flask import Flask, request, render_template, redirect, url_for, flash, session
import json
import os
import uuid
from bcrypt import hashpw, gensalt, checkpw

# Helper functions to read/write JSON files
def read_json(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            return json.load(file)
    return {}

def write_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

def read_list_json(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            return json.load(file)
    return []

def write_list_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

# File paths for storing data
users_file = 'users.json'
payments_file = 'payments.json'
suspicious_activities_file = 'suspicious_activities.json'
bad_ips_file = 'bad_ip_dataset.txt'

# Load bad IPs
def load_bad_ips():
    with open(bad_ips_file, 'r') as file:
        bad_ips = set(line.strip() for line in file if line.strip())
    return bad_ips

# Check if IP is blacklisted
def check_ip_blacklist(ip_address, bad_ips):
    return ip_address in bad_ips

# Check user behavior
def check_user_behavior(user_id, transaction_amount):
    payments = read_list_json(payments_file)
    user_payments = [p for p in payments if p['from_user'] == user_id]
    if not user_payments:
        return False
    average = sum(p['amount'] for p in user_payments) / len(user_payments)
    return transaction_amount > 2 * average  # Arbitrary factor of 2

# Log suspicious activity
def log_suspicious_activity(message, user_id):
    activities = read_list_json(suspicious_activities_file)
    activities.append({"user_id": user_id, "message": message, "timestamp": datetime.datetime.now().isoformat()})
    write_list_json(activities, suspicious_activities_file)

# User registration
def create_account(username, password):
    users = read_json(users_file)
    if username in users:
        return 'Username already exists'
    hashed_password = hashpw(password.encode('utf-8'), gensalt()).decode('utf-8')
    users[username] = {'username': username, 'password': hashed_password}
    write_json(users, users_file)
    return 'Account created successfully'

# User login
def login(username, password):
    users = read_json(users_file)
    user = users.get(username)
    if user and checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
        return user['username']
    else:
        return None

# Request payment
def request_payment(from_user, to_user, amount):
    payments = read_list_json(payments_file)
    payment_id = str(uuid.uuid4())
    payments.append({'id': payment_id, 'from_user': from_user, 'to_user': to_user, 'amount': amount, 'status': 'pending', 'timestamp': datetime.datetime.now().isoformat()})
    write_list_json(payments, payments_file)
    return payment_id

# Complete payment
def complete_payment(payment_id, user_ip, bad_ips):
    payments = read_list_json(payments_file)
    payment = next((p for p in payments if p.get('id') == payment_id), None)
    if not payment:
        return 'Payment not found'

    if check_ip_blacklist(user_ip, bad_ips):
        log_suspicious_activity(f"Transaction blocked due to risk associated with IP {user_ip}", payment['from_user'])
        return 'Transaction blocked due to risk associated with the IP address.'

    payment['status'] = 'completed'
    write_list_json(payments, payments_file)
    return 'Payment completed successfully!'

# Add bad IP
def add_bad_ip(ip_address):
    with open(bad_ips_file, 'a') as file:
        file.write(ip_address + '\n')
    return 'Bad IP added successfully'

# Migration function to add 'id' field to existing payments
def migrate_payments_to_add_id():
    payments = read_list_json(payments_file)
    updated = False
    for payment in payments:
        if 'id' not in payment:
            payment['id'] = str(uuid.uuid4())
            updated = True
    if updated:
        write_list_json(payments, payments_file)

# Initialize app and load bad IPs
app = Flask(__name__)
app.secret_key = 'your_secret_key'
bad_ips = load_bad_ips()
migrate_payments_to_add_id()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/create_account', methods=['GET', 'POST'])
def create_account_route():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        message = create_account(username, password)
        flash(message)
        return redirect(url_for('home'))
    return render_template('create_account.html')

@app.route('/login', methods=['GET', 'POST'])
def login_route():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_id = login(username, password)
        if user_id:
            session['username'] = user_id
            flash(f"User logged in with ID: {user_id}")
            return redirect(url_for('home'))
        else:
            flash("Login failed")
            return redirect(url_for('login_route'))
    return render_template('login.html')

@app.route('/request_payment', methods=['GET', 'POST'])
def request_payment_route():
    if 'username' not in session:
        flash("Please log in first.")
        return redirect(url_for('login_route'))
    if request.method == 'POST':
        to_user = request.form['to_user']
        amount = float(request.form['amount'])
        payment_id = request_payment(session['username'], to_user, amount)
        flash(f"Payment request created with ID: {payment_id}")
        return redirect(url_for('home'))
    return render_template('request_payment.html')

@app.route('/complete_payment', methods=['GET', 'POST'])
def complete_payment_route():
    if 'username' not in session:
        flash("Please log in first.")
        return redirect(url_for('login_route'))
    if request.method == 'POST':
        payment_id = request.form['payment_id']
        user_ip = request.form['user_ip']
        message = complete_payment(payment_id, user_ip, bad_ips)
        flash(message)
        return redirect(url_for('home'))
    return render_template('complete_payment.html')

@app.route('/add_bad_ip', methods=['GET', 'POST'])
def add_bad_ip_route():
    if request.method == 'POST':
        ip_address = request.form['ip_address']
        message = add_bad_ip(ip_address)
        flash(message)
        return redirect(url_for('home'))
    return render_template('add_bad_ip.html')
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out.')
    return redirect(url_for('home'))
if __name__ == '__main__':
    app.run(debug=True)
